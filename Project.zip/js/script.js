function changeColor(color) {
  // Change the background color of the Best Offer legend
  const bestOffer = document.querySelector('legend[data-i18n="best-offer"]');
  if (bestOffer) {
    bestOffer.style.backgroundColor = color;
  }

  // Change the background color of the Product Details legend
  const productDetails = document.querySelector(
    'legend[data-i18n="product-details"]'
  );
  if (productDetails) {
    productDetails.style.backgroundColor = color;
  }

    // Change the background color of 2 buttons language and color
    const legendbuttons = document.getElementById('language-btn');
    if (legendbuttons) {
      legendbuttons.style.backgroundColor = color;
    }
        // Change the background color of 2 buttons language and color
        const legendbuttons1 = document.getElementById('color-menu-btn');
        if (legendbuttons1) {
          legendbuttons1.style.backgroundColor = color;
        }

  // Change the text color of the Items legend
  const items = document.querySelector('legend[data-i18n="items"]');
  if (items) {
    items.style.backgroundColor = color;
  }

  // Change the background color of the Add Item button
  const addItemButton = document.querySelector(
    '#add-item[data-i18n="add-item-button"]'
  );
  if (addItemButton) {
    addItemButton.style.backgroundColor = color;
  }

  // Change the background color of the Clear Items button
  const clearItemsButton = document.querySelector(
    '#clear-items[data-i18n="clear-items-button"]'
  );
  if (clearItemsButton) {
    clearItemsButton.style.backgroundColor = color;
  }

  // Change the background color of the floating button
  const floatingButton = document.querySelector(".floating-button");
  if (floatingButton) {
    floatingButton.style.backgroundColor = color;
  }

  // Change the color of the color icon
  const colorIcon = document.querySelector("#color-icon");
  if (colorIcon) {
    colorIcon.style.backgroundColor = color;
  }
}

var infoButton = document.getElementById("info-button");
var infoPopup = document.getElementById("info-popup");
var closeButton = document.getElementsByClassName("close-button")[0];
infoButton.onclick = function () {
  infoPopup.style.display = "block";
};
closeButton.onclick = function () {
  infoPopup.style.display = "none";
};
window.onclick = function (event) {
  if (event.target == infoPopup) {
    infoPopup.style.display = "none";
  }
};

// Δημιουργούμε τοπικό αντίγραφο της λίστας των αντικειμένων
let items = JSON.parse(localStorage.getItem("items")) || [];

// Καλούμε τη συνάρτηση renderItems() για να εμφανίσουμε τα αντικείμενα στη σελίδα
renderItems();
calculateBestOffer();

// Συνάρτηση για προσθήκη ενός αντικειμένου στη λίστα
function addItem() {
  const input = document.getElementById("item-input");
  const value = input.value.trim();

  if (value === "") {
    alert("Please enter a value for the item.");
    return;
  }

  // Create a new item and add it to the list
  const newItem = {
    id: Date.now(),
    value: value,
  };
  items.push(newItem);

  // Send only the new item data to the server as a JSON string
  fetch("/save-item", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(newItem),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Unable to save the item.");
      }
      // Render the items on the page
      renderItems();
      // Clear the input field
      input.value = "";
    })
    .catch((error) => {
      console.error(error);
      alert("Unable to save the item. Please try again later.");
    });
  renderItems();
}

function renderItems() {
  const itemsDiv = document.getElementById("items");
  itemsDiv.innerHTML = "";
  items.forEach((item, i) => {
    const itemDiv = document.createElement("tr");
    itemDiv.classList.add("item");

    const indexLabel = document.createElement("td");
    indexLabel.classList.add("item-index");
    indexLabel.textContent = `${i + 1}`;

    const priceAmountLabel = document.createElement("td");
    priceAmountLabel.classList.add("item-label");
    priceAmountLabel.textContent = `${item.price.toFixed(2)}€`;

    const amountLabel = document.createElement("td");
    amountLabel.classList.add("item-label");
    amountLabel.textContent = `${item.amount}`;

    const costPerUnitLabel = document.createElement("td");
    costPerUnitLabel.classList.add("item-label");
    costPerUnitLabel.textContent = `${calculatePricePerProduct(item).toFixed(
      2
    )}€`;

    const removeButton = document.createElement("button");
    removeButton.classList.add("item-button");
    removeButton.innerHTML = '<i class="fas fa-times"></i>';
    removeButton.setAttribute("title", "Remove");

    const buttonLabel = document.createElement("td");
    buttonLabel.classList.add("item-button-label");
    buttonLabel.appendChild(removeButton);

    itemDiv.appendChild(indexLabel);
    itemDiv.appendChild(priceAmountLabel);
    itemDiv.appendChild(amountLabel);
    itemDiv.appendChild(costPerUnitLabel);
    itemDiv.appendChild(buttonLabel);

    itemsDiv.appendChild(itemDiv);

    indexLabel.addEventListener("click", () => {
      const priceInput = document.createElement("input");
      priceInput.classList.add("item-price");
      priceInput.type = "number";
      priceInput.step = "0.01";
      priceInput.required = "true";
      priceInput.value = item.price.toFixed(2);
      priceAmountLabel.innerHTML = "Price €: ";
      priceAmountLabel.appendChild(priceInput);

      const amountInput = document.createElement("input");
      amountInput.classList.add("item-amount");
      amountInput.type = "number";
      amountInput.step = "0.01";
      amountInput.required = "true";
      amountInput.value = item.amount;
      amountLabel.innerHTML = "Amount: ";
      amountLabel.appendChild(amountInput);

      costPerUnitLabel.textContent = `${calculatePricePerProduct(item).toFixed(
        2
      )}€`;

      calculateBestOffer();
    });

    removeButton.addEventListener("click", () => {
      items.splice(i, 1);
      renderItems();
      calculateBestOffer();
    });

    itemDiv.addEventListener("mouseleave", () => {
      priceAmountLabel.textContent = `${item.price.toFixed(2)}€`;
      amountLabel.textContent = `${item.amount}`;
      costPerUnitLabel.textContent = `${calculatePricePerProduct(item).toFixed(
        2
      )}€`;
    });

    itemDiv.addEventListener("mouseenter", () => {
      itemDiv.style.backgroundColor = "#f2f2f2";
    });

    itemDiv.addEventListener("mouseleave", () => {
      itemDiv.style.backgroundColor = "transparent";
    });

    itemsDiv.appendChild(itemDiv);
  });

  localStorage.setItem("items", JSON.stringify(items));
}

function calculatePricePerProduct(item) {
  const packagePricePerItem = item.price / item.amount;
  return packagePricePerItem;
}

function calculateBestOffer() {
  let bestPricePerAmountOffer = null;
  let bestPricePerAmountOption = null;
  let bestPricePerMoneyOffer = null;
  let bestPricePerMoneyOption = null;

  items.forEach((item, index) => {
    const pricePerAmount = item.price / item.amount;
    const pricePerMoney = item.amount / item.price;

    if (
      pricePerAmount !== null &&
      (!bestPricePerAmountOffer || pricePerAmount < bestPricePerAmountOffer)
    ) {
      bestPricePerAmountOffer = pricePerAmount;
      bestPricePerAmountOption = index + 1;
    }

    if (
      pricePerMoney !== null &&
      (!bestPricePerMoneyOffer || pricePerMoney > bestPricePerMoneyOffer)
    ) {
      bestPricePerMoneyOffer = pricePerMoney;
      bestPricePerMoneyOption = index + 1;
    }
  });

  if (bestPricePerAmountOffer !== null && bestPricePerAmountOption !== null) {
    const pricePerAmountLabel = document.getElementById("price-per-amount");
    const pricePerAmountStr = bestPricePerAmountOffer.toFixed(2);
    const optionPerAmountLabel = `Option ${bestPricePerAmountOption}`;
    const pricePerAmountOfferStr = `<img src="images/left.gif" style="width: 2.5em;margin: 0 0 -11px 0;"> ${optionPerAmountLabel} offers the best price per unit at ${pricePerAmountStr}€`;
    pricePerAmountLabel.innerHTML = `${pricePerAmountOfferStr}`;
  }
}

document.getElementById("add-item").addEventListener("click", addNewItem);

function addNewItem() {
  const priceInput = document.getElementById("price");
  const amountInput = document.getElementById("amount");
  const price = parseFloat(priceInput.value);
  const amount = parseFloat(amountInput.value);
  if (!isNaN(price) && !isNaN(amount) && amount > 0) {
    const newItem = { id: Date.now(), price: price, amount: amount };
    items.push(newItem);
    renderItems();
    calculateBestOffer();
    priceInput.value = "";
    amountInput.value = "";
  } else {
    alert("Please enter valid price and amount values.");
  }
}

var itemList = document.getElementById("item-list");
function addItem() {
  var itemInput = document.getElementById("item-input");
  var newItem = document.createElement("li");
  newItem.textContent = itemInput.value;
  itemList.appendChild(newItem);
  itemInput.value = "";
}

function clearItems() {
  items = [];
  renderItems();

  localStorage.removeItem("items");

  // Reset the best offer label
  const bestOfferLabel = document.getElementById("best-offer");
  bestOfferLabel.textContent = "";
  calculateBestOffer();
}



document.getElementById("add-item").addEventListener("click", addItem);
document.getElementById("clear-items").addEventListener("click", clearItems);

const langSelect = document.getElementById('language-select');
const popup = document.getElementById('info-popup');
const popupContent = document.querySelector('.popup-content');
const listTitle = document.querySelector('legend[data-i18n="items"]');
const clearBtn = document.getElementById('clear-items');
const addBtn = document.getElementById('add-item');
const bestofferl = document.querySelector('legend[data-i18n="best-offer"]');
const productdetailsl = document.querySelector('legend[data-i18n="product-details"]');
const idHeader = document.querySelector('th[data-i18n="id"]');
const priceHeader = document.querySelector('th[data-i18n="price"]');
const amountHeader = document.querySelector('th[data-i18n="amount"]');
const costPerUnitHeader = document.querySelector('th[data-i18n="cost-per-unit"]');
const actionsHeader = document.querySelector('th[data-i18n="actions"]');
const pricePerAmountColumn = document.querySelector('label[data-i18n="amount-label"]');
const pricelabel = document.querySelector('label[data-i18n="price-label"]');
const pricePerAmountText = document.getElementById('price-per-amount');

const body = document.body;

let language = 'en';

langSelect.addEventListener('click', function(event) {
  if (event.target.parentElement.getAttribute('data-lang')) {
    language = event.target.parentElement.getAttribute('data-lang');
    updateLanguage();
  }
});

function updateLanguage() {
  if (language === 'el') {
    listTitle.textContent = 'Λίστα Αγορών';
    bestofferl.textContent = 'Η καλύτερη Προσφορά';
    productdetailsl.textContent = 'Πληροφορίες προιόντος ';
    popupContent.textContent = ' Αυτή είναι μια εφαρμογή όπου μπορείτε να κάνετε μια λίστα με πράγματα που θέλετε να αγοράσετε. Μπορείτε να προσθέσετε στοιχεία στη λίστα πληκτρολογώντας και την τιμή τους και, στη συνέχεια, κάνοντας κλικ σε ένα κουμπί. Ο ιστότοπος θα σας εμφανίσει τη λίστα με τα είδη που καταχωρίσατε και θα υπολογίσει απο την λίστα ποιο αντικείμενο είναι η καλύτερη προσφορά.  Εάν θέλετε να αφαιρέσετε ένα στοιχείο από τη λίστα, μπορείτε να κάνετε κλικ σε ένα κουμπί δίπλα σε αυτό το στοιχείο [Χ]. Εάν θέλετε να αφαιρέσετε όλα τα στοιχεία από τη λίστα, μπορείτε να κάνετε κλικ στο κουμπί [Clear Items].  Ο ιστότοπος θα θυμάται τη λίστα των στοιχείων που εισαγάγατε, επομένως εάν επιστρέψετε στον ιστότοπο αργότερα, θα εξακολουθείτε να βλέπετε τη λίστα σας. ';
    clearBtn.textContent = 'Εκαθάρηση λίστας';
    addBtn.textContent = 'Προσθήκη Στοιχείου';
    body.classList.remove('bg-light');
    body.classList.add('bg-info');
    idHeader.textContent = 'A/A';
    priceHeader.innerHTML = 'Τιμή (σε<b>€</b>)';
    amountHeader.textContent = 'Ποσότητα';
    costPerUnitHeader.textContent = 'Κόστος ανά μονάδα 📦';
    actionsHeader.textContent = 'Ενέργειες';
    pricePerAmountColumn.textContent = 'Τιμή € : ';
    pricelabel.textContent = 'Ποσότητα : ';
    pricePerAmountText.textContent = `<img src="images/left.gif" style="width: 2.5em;margin: 0 0 -11px 0;"> ${optionPerAmountLabel} προσφέρει την καλύτερη τιμή ανα μονάδα ${pricePerAmountStr}€`;
  } else {
    listTitle.textContent = 'Shopping List';
    bestofferl.textContent = 'Best Offer';
    productdetailsl.textContent = 'Product details';
    popupContent.textContent = 'This is an app where you can make a list of things you want to buy. You can add items to the list by typing their value and then clicking a button.The site will show you the list of items you entered and will calculate from the list which item is the best offer.  If you want to remove an item from the list, you can click a button next to that item [X]. If you want to remove all items from the list,you can click the [Clear Items] button.  The site will remember the list of items you entered, so if you return to the site later, you"ll still see your list. Clear Items';
    addBtn.textContent = 'Add Item';
    body.classList.remove('bg-info');
    body.classList.add('bg-light');
    idHeader.textContent = 'ID';
    priceHeader.innerHTML = 'Price (in Euro <b>€</b>)';
    amountHeader.textContent = 'Amount';
    costPerUnitHeader.textContent = 'Cost per unit 📦';
    actionsHeader.textContent = 'Actions';
    pricePerAmountColumn.textContent = 'Price € : ';
    pricelabel.textContent = 'Amount : ';
    pricePerAmountOfferStr.textContent = `<img src="images/left.gif" style="width: 2.5em;margin: 0 0 -11px 0;"> ${optionPerAmountLabel} offers the best price per unit at ${pricePerAmountStr}€`;
   
   }
   
}

updateLanguage();


addBtn.addEventListener('click', function() {
  const itemInput = document.getElementById('item-input');

  if (itemInput.value !== '') {
    const newItem = document.createElement('li');
    newItem.className = 'list-group-item';
    newItem.appendChild(document.createTextNode(itemInput.value));

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn btn-outline-danger btn-sm float-end delete';
    deleteBtn.appendChild(document.createTextNode('X'));
    newItem.appendChild(deleteBtn);

    const itemList = document.getElementById('item-list');
    itemList.appendChild(newItem);

    itemInput.value = '';
  }
});

clearBtn.addEventListener('click', function() {
  const itemList = document.getElementById('item-list');
  while (itemList.firstChild) {
    itemList.removeChild(itemList.firstChild);
  }
});
